<?php

abstract class LiveChatHelper
{
	abstract public function render();
}
